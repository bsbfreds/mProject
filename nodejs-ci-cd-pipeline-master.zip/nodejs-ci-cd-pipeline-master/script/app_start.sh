#!/bin/bash
pm2 start /usr/cddemo/index.js