#!/bin/bash
cd /usr/cddemo
npm i