#!/bin/bash
pm2 kill